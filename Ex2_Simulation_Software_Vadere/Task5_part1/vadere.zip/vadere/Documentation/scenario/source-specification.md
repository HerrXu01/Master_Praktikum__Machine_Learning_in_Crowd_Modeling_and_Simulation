# Source Specification

<!---
@author Aleksandar Ivanov(ivanov0@hm.edu)
-->

| Attribute | Type | Description |
|:---------:|:----:|:-----------:|
id | int |
shape | TODO |
interSpawnTimeDistribution | see [Distribution Specification](./distribution/distribution-specification.md) | corresponds to Name
distributionParameters | see [Distribution Specification](./distribution/distribution-specification.md) | corresponds to Parameter
... | ... | ...
