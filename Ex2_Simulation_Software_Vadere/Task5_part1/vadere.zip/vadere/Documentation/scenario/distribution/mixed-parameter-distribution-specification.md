# MixedParameterDistribution Specification

<!---
@author Aleksandar Ivanov(ivanov0@hm.edu)
-->

| Attribute | Type | Description |
|:---------:|:----:|:-----------:|
interSpawnTimeDistribution | [Distribution Specification](./distribution-specification.md) | corresponds to Name
distributionParameters | [Distribution Specification](./distribution-specification.md) | corresponds to Parameter
