# LinearInterpolationParameter Specification

<!---
@author Aleksandar Ivanov(ivanov0@hm.edu)
-->

| Attribute | Type | Description |
|:---------:|:----:|:-----------:|
spawnFrequency | double |
xValues | double[] |
yValues | double[] |
