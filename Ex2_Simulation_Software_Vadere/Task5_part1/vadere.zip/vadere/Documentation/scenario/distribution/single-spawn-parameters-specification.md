# SingleSpawnParameter Specification

<!---
@author Aleksandar Ivanov(ivanov0@hm.edu)
-->

| Attribute | Type | Description |
|:---------:|:----:|:-----------:|
spawnTime | double |
spawnNumber | int |
