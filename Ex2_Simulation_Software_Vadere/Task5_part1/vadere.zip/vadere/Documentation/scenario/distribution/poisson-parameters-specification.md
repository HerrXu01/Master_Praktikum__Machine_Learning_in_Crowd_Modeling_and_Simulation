# BinomialParameter Specification

<!---
@author Aleksandar Ivanov(ivanov0@hm.edu)
-->

| Attribute | Type | Description |
|:---------:|:----:|:-----------:|
numberPedsPerSecond | double |
