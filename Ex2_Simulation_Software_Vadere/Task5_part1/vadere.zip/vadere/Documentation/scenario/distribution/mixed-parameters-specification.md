# MixedParameter Specification

<!---
@author Aleksandar Ivanov(ivanov0@hm.edu)
-->

| Attribute | Type | Description |
|:---------:|:----:|:-----------:|
switchpoints | int[] |
distributions | [MixedParameterDistribution](./mixed-parameter-distribution-specification.md)[] |
