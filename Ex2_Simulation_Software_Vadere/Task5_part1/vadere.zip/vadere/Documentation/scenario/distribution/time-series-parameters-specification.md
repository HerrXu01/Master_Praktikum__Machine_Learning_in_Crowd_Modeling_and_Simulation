# TimeSeriesParameter Specification

<!---
@author Aleksandar Ivanov(ivanov0@hm.edu)
-->

| Attribute | Type | Description |
|:---------:|:----:|:-----------:|
intervalLength | double |
spawnsPerInterval | int[] |
