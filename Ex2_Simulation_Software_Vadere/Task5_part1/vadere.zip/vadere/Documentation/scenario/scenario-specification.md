# Scenario Specification

<!---
@author Aleksandar Ivanov(ivanov0@hm.edu)
-->

| Attribute | Type | Description |
|:---------:|:----:|:-----------:|
mainModel | string |
... | ... | ...
sources | [Source](./source-specification.md)[] |
