This folder serves as a javascript module for the HelpTextView.
The HelpTextView scans all .js files and instantiates them inside the .html files on load.
This is useful for creating clean documentation inside the javadoc, which is still readable in code editors
