package org.vadere.gui.topographycreator.control.attribtable.tree;

public class TreeException extends Exception {
}
