package org.vadere.gui.topographycreator.control.attribtable.tree;

public interface StructureListener {
    void structureChanged(AttributeTreeModel.TreeNode node);
}
