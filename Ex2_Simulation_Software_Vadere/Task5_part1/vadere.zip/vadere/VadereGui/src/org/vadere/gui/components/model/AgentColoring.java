package org.vadere.gui.components.model;

public enum AgentColoring {
	TARGET, RANDOM, GROUP, EVACUATION_TIMES, PREDICATE, SELF_CATEGORY, HEALTH_STATUS, INFORMATION_STATE;
}
