package org.vadere.gui.components.view;

import org.vadere.state.scenario.ScenarioElement;

public interface ISelectScenarioElementListener {
	void selectionChange(final ScenarioElement scenarioElement);
}
