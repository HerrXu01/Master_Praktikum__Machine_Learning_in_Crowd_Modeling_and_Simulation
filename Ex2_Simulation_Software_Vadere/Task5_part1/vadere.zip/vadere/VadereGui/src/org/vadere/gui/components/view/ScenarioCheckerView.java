package org.vadere.gui.components.view;

import org.vadere.gui.projectview.view.AttributeType;
import org.vadere.gui.projectview.view.TextView;
import org.vadere.state.scenario.ScenarioElement;

import java.util.HashMap;

import javax.swing.*;
import javax.swing.event.HyperlinkEvent;

public class ScenarioCheckerView extends JEditorPane {


}