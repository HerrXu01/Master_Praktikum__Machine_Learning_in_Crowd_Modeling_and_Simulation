package org.vadere.gui.projectview.model;

import org.vadere.simulator.projects.Scenario;

public interface IScenarioChecker {

	void checkScenario(final Scenario scenario);

}
