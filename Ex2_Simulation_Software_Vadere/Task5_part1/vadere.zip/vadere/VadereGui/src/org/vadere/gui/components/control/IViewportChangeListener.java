package org.vadere.gui.components.control;

public interface IViewportChangeListener {

	void viewportChange(final ViewportChangeEvent event);

}
