package org.vadere.gui.topographycreator.control.attribtable;

public interface ViewListener {
    void viewChanged(Object object);
}
