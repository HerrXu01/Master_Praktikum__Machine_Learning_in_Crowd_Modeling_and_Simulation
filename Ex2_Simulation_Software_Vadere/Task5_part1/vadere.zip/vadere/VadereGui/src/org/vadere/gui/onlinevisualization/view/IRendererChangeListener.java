package org.vadere.gui.onlinevisualization.view;

import org.vadere.gui.components.view.SimulationRenderer;

public interface IRendererChangeListener {
	void update(final SimulationRenderer renderer);
}
