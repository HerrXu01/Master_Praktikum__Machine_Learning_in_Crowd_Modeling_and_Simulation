package org.vadere.gui.compileScripts;


import org.vadere.util.logging.Logger;

/**
 * @author Benedikt Zoennchen
 *
 * Example: This script runs during the maven package phase.
 */
public class ClassListGenerator {

    private static Logger log = Logger.getLogger(ClassListGenerator.class);

    public static void main(String... args) {

    }

}
