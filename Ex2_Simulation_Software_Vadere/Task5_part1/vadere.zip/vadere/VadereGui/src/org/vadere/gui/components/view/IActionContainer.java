package org.vadere.gui.components.view;

import javax.swing.Action;
import javax.swing.JButton;

public interface IActionContainer {
	JButton add(Action action);
}
