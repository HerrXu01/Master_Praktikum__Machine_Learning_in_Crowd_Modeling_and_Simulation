# Vadere Analysis Tool

Simplify import and analysis of simulation output in python an juypter-notebooks