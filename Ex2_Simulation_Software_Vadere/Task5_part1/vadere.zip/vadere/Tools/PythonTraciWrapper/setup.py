from distutils.core import setup

setup(
    name='PythonTraciWrapper',
    version='0.2',
    packages=['pythontraciwrapper'],
    url='',
    license='',
    author='Philipp Schuegraf',
    author_email='',
    description='Wrapper around py4j to communicate with vadere via TraCI.'
)
