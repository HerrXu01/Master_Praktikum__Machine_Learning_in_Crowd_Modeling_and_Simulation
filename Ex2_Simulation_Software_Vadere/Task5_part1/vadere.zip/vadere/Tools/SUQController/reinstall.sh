sudo -H pip3 uninstall suqc
sudo python3 setup.py install 
